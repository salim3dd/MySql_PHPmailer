<?php 
include("../config.php"); 

header('Content-Type: text/html; charset=utf-8');

  
 $email = strip_tags(trim($_POST["email"]));
  
$sql_query = "SELECT * FROM Users WHERE Email LIKE '$email' "; 
$result_Users = $conn->query($sql_query);
		while($row = $result_Users->fetch_assoc()) {				    
			$username = $row['UserName'];
			$pass = $row['Password'];
			$Emailrow = $row['Email'];
		    }


if ($email == $Emailrow){
 
require("PHPMailer/class.phpmailer.php");
			
$mail = new PHPMailer();
$mail->CharSet = 'UTF-8';
$mail->IsSMTP();
$mail->Host = "smtp.flockmail.com";
$mail->SMTPAuth = true;
$mail->Username = "info@novbook.net";
$mail->Password = "باسوورد الايميل";
$mail->From = "info@novbook.net";
$mail->SMTPSecure = "tls";
$mail->Port = 587;
$mail->FromName = "info@novbook.net";
$mail->AddAddress("{$email}");
$mail->WordWrap = 50;
$mail->IsHTML(true);
            
$mail->Subject = "استعادة كلمة المرور";
$mail->Body    = "UserName: {$username}<br>PassWord:{$pass}";
$mail->AltBody = "";

			if(!$mail->Send())
			{
			   $check = "Send_Error";   			
			   echo "Mailer Error: " . $mail->ErrorInfo;
			   exit;
			}else{
				$check = "Send_OK";       
			}

}else{
$check = "No_Email";    
}

  $json_re=array();
	array_push($json_re,array("success"=>$check));
    echo json_encode($json_re);
    

?> 
  